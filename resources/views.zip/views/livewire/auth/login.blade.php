<div class="min-h-screen w-full flex items-center justify-center bg-white dark:bg-[#0a0a0a] py-6 px-4 sm:px-6 lg:px-8 overflow-y-auto">
    <div class="w-full max-w-sm sm:max-w-md bg-zinc-50 dark:bg-white/[0.02] border border-zinc-200 dark:border-white/10 p-6 sm:p-10 rounded-2xl sm:rounded-[2.5rem] shadow-2xl text-center my-auto">
        
        <h2 class="text-xl sm:text-2xl font-black text-zinc-900 dark:text-white uppercase italic mb-6 sm:mb-10 tracking-tighter break-words">
            Bienvenue chez <span class="text-red-600">IBM MOTORS</span>
        </h2>

        <form wire:submit.prevent="authenticate" class="space-y-4 sm:space-y-6">
            <div class="space-y-1.5 text-left">
                <label class="text-[10px] sm:text-xs font-black text-zinc-400 uppercase ml-2 tracking-widest block">Téléphone ou Adresse Email</label>
                <input wire:model="login" type="text" placeholder="05XXXXXXXX / exemple@email.com" class="w-full bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-white/5 py-3 sm:py-4 px-4 sm:px-6 rounded-xl sm:rounded-2xl text-sm dark:text-white outline-none focus:border-red-600 transition-all shadow-inner text-left">
            </div>

            <div class="space-y-1.5 text-left">
                <div class="flex justify-between items-center ml-2">
                    <label class="text-[10px] sm:text-xs font-black text-zinc-400 uppercase tracking-widest block">Mot de passe</label>
                </div>
                <input wire:model="password" type="password" placeholder="••••••••" class="w-full bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-white/5 py-3 sm:py-4 px-4 sm:px-6 rounded-xl sm:rounded-2xl text-sm dark:text-white outline-none focus:border-red-600 transition-all shadow-inner text-left">
            </div>

            <button type="submit" class="w-full bg-zinc-900 dark:bg-white text-white dark:text-black py-3.5 sm:py-4.5 rounded-xl sm:rounded-2xl font-black text-xs uppercase tracking-wider sm:tracking-[0.2em] hover:scale-[1.01] active:scale-95 transition-all shadow-xl block dynamic-btn">
                Connexion Sécurisée
            </button>
        </form>

        <p class="mt-6 sm:mt-8 text-[10px] sm:text-xs font-bold text-zinc-500 uppercase tracking-widest">
            Pas de compte ? <a href="{{ route('register') }}" class="text-red-600 hover:underline transition-colors">Inscrivez-vous</a>
        </p>
    </div>
</div>