<!-- Services Section Begin -->
<section class="services spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-title">
                    <span>Nos Services</span>
                    <h2>Ce que nous offrons</h2>
                    <p>Découvrez nos services complets conçus pour faciliter l'achat, la vente et l'échange de véhicules.</p>
                </div>
            </div>
        </div>
        <div class="row">
            <!-- Service 1 -->
            <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                <div class="services__item">
                    <img src="{{ asset('front/img/services/services-1.png') }}" alt="Achat de voitures" class="img-fluid">
                    <h5>Achat de Voitures</h5>
                    <p>Explorez notre large gamme de voitures inspectées et certifiées prêtes pour le marché local.</p>
                    <a href="#"><i class="fa fa-long-arrow-right"></i></a>
                </div>
            </div>
            
            <!-- Service 2 -->
            <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                <div class="services__item">
                    <img src="{{ asset('front/img/services/services-2.png') }}" alt="Vente de voitures" class="img-fluid">
                    <h5>Vente Simplifiée</h5>
                    <p>Déposez votre annonce en quelques clics et entrez en contact direct avec des acheteurs sérieux.</p>
                    <a href="#"><i class="fa fa-long-arrow-right"></i></a>
                </div>
            </div>
            
            <!-- Service 3 -->
            <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                <div class="services__item">
                    <img src="{{ asset('front/img/services/services-3.png') }}" alt="Échange de véhicules" class="img-fluid">
                    <h5>Échange Rapide</h5>
                    <p>Échangez votre voiture actuelle contre un nouveau modèle de notre catalogue avec une estimation juste.</p>
                    <a href="#"><i class="fa fa-long-arrow-right"></i></a>
                </div>
            </div>
            
            <!-- Service 4 -->
            <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                <div class="services__item">
                    <img src="{{ asset('front/img/services/services-4.png') }}" alt="Support 24/7" class="img-fluid">
                    <h5>Support 24/7</h5>
                    <p>Notre équipe vous accompagne à chaque étape pour garantir une transaction sécurisée et transparente.</p>
                    <a href="#"><i class="fa fa-long-arrow-right"></i></a>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Services Section End -->

<!-- تنسيقات إضافية لدمج ألوان الهوية البصرية الجديدة في قسم الخدمات -->
<style>
    /* تعديل لون العنوان الصغير (العلامة العلوية) إلى الذهبي الفخم */
    .services .section-title span {
        color: #c18f54 !important;
        text-transform: uppercase;
        letter-spacing: 2px;
    }

    /* تعديل أسهم الانتقال الافتراضية إلى اللون الفضي/الرمادي */
    .services__item a {
        color: #c2c2c2 !important;
        transition: all 0.3s ease;
    }

    /* تأثير التمرير (Hover): تغيير لون السهم والخلفية أو الأنماط التفاعلية إلى الذهبي */
    .services__item:hover a {
        color: #c18f54 !important;
    }

    /* إذا كان القالب الأصلي يرسم خطاً تحت العنوان عند التمرير */
    .services__item:after {
        background: #c18f54 !important;
    }
</style>