<section class="car spad" id="collections">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="space-y-2 mb-4 text-center text-md-left">
                    <!-- تم تغيير اللون الأحمر القديم هنا إلى الفضي #c2c2c2 كخلفية نصية ثانوية ناعمة -->
                    <span class="text-brand font-black tracking-[0.4em] text-[10px] uppercase block" style="color: #c2c2c2; letter-spacing: 3px;">LATEST DROP</span>
                    <!-- ترجمة العنوان وتغيير النقطة التجميلية إلى اللون الذهبي #c18f54 -->
                    <h2 class="text-4xl md:text-5xl font-black tracking-tighter text-zinc-900 dark:text-white uppercase" style="font-weight: 900; font-size: 2.5rem;">
                        Arrivages Récents<span class="text-brand" style="color: #c18f54;">.</span>
                    </h2>
                </div>
                
                <div class="d-flex flex-column flex-md-row justify-content-between align-items-center mb-5 gap-3">
                    <ul class="filter__controls m-0 p-0 d-flex flex-wrap gap-2 justify-content-center">
                        <li class="active" data-filter="*">Tous les véhicules</li>
                        <li data-filter=".sale">Dernières Ventes</li>
                    </ul>
                    
                    <!-- ترجمة زر الاكتشاف وتغيير اتجاه السهم ليناسب الانسيابية الفرنسية LTR -->
                    <a href="{{ route('ads.index') }}" class="group d-flex align-items-center gap-2 text-uppercase tracking-widest font-weight-bold text-secondary discover-link" style="font-size: 12px; letter-spacing: 1px; text-decoration: none;">
                        Découvrir plus 
                        <i class="fa-solid fa-arrow-right-long transition-transform mx-2"></i>
                    </a>
                </div>
            </div>
        </div>
        
        <div class="row car-filter gy-4">
            @forelse($recentAds as $ad)
                <div class="col-lg-3 col-md-4 col-sm-6 col-12 mix {{ $ad->purpose == 'sale' ? 'sale' : '' }}">
                    <!-- أضفنا كلاس position-relative هنا ليعمل الرابط الشامل على الكارت بالكامل -->
                    <div class="car__item position-relative">
                        
                        <!-- 1. سلايدر الصور (بدون روابط داخلية تسبب تداخل) -->
                        <div class="car__item__pic__slider owl-carousel">
                            @if($ad->images && $ad->images->isNotEmpty())
                                @foreach($ad->images as $img)
                                    <img src="{{ asset('storage/' . $img->image_path) }}" alt="{{ $ad->title }}" style="object-fit: cover; height: 230px; width: 100%;">
                                @endforeach
                            @elseif($ad->primaryImage) <!-- تم تصحيح الكلمة هنا إلى elseif بدلاً من elif -->
                                <img src="{{ asset('storage/' . $ad->primaryImage->image_path) }}" alt="{{ $ad->title }}" style="object-fit: cover; height: 230px; width: 100%;">
                            @else
                                <div class="w-full h-full d-flex align-items-center justify-content-center bg-light text-muted" style="height: 230px;">
                                    <i class="fa-solid fa-image text-5xl" style="font-size: 3rem;"></i>
                                </div>
                            @endif
                        </div>
                        
                        <!-- 2. النصوص بتنسيقها الأصلي الأنيق دون أي كسر للهيكل -->
                        <div class="car__item__text">
                            <div class="car__item__text__inner">
                                <div class="label-date">{{ $ad->year ?? ($ad->category->name ?? 'Auto') }}</div>
                                <h5>
                                    <!-- كلاس stretched-link هنا يجعل الكرت بالكامل قابلاً للضغط دون تغيير في تصميمه -->
                                    <a href="{{ route('ads.show', $ad->slug) }}" class="stretched-link text-decoration-none text-dark dark:text-white">{{ $ad->title }}</a>
                                </h5>
                                <ul>
                                    <li><span>{{ $ad->mileage ?? '0' }}</span> km</li>
                                    <li>{{ $ad->transmission ?? 'Auto' }}</li>
                                    <li><span>{{ $ad->engine_power ?? '700' }}</span> ch</li>
                                </ul>
                            </div>
                            
                            <div class="car__item__price">
                                <span class="car-option {{ $ad->purpose == 'sale' ? 'sale' : '' }}">
                                    {{ $ad->purpose == 'sale' ? 'À Vendre' : 'Échange' }}
                                </span>
                                <h6>{{ number_format($ad->price) }} <span>DA</span></h6>
                            </div>
                        </div>
                        
                    </div>
                </div>
            @empty
                @for($i = 0; $i < 4; $i++)
                    <div class="col-lg-3 col-md-4 col-sm-6 col-12">
                        <div class="car__item" style="opacity: 0.6; animation: pulse 1.5s infinite ease-in-out;">
                            <div style="height: 230px; background: #eee; border-radius: 5px;"></div>
                            <div class="p-3">
                                <div style="height: 15px; width: 40%; background: #eee; margin-bottom: 10px; border-radius: 4px;"></div>
                                <div style="height: 20px; width: 80%; background: #eee; margin-bottom: 15px; border-radius: 4px;"></div>
                                <div style="height: 15px; width: 100%; background: #eee; border-radius: 4px;"></div>
                            </div>
                        </div>
                    </div>
                @endfor
            @endforelse
        </div>
    </div>
</section>

<!-- كود الـ CSS المحدث والمحسن -->
<style>
    /* إضافة لمسة تفاعلية للكرت بالكامل عند تمرير الماوس */
    .car__item {
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    
    .car__item:hover {
        transform: translateY(-6px);
        box-shadow: 0 10px 25px rgba(0,0,0,0.08);
    }

    /* تفاعل العنوان مع التمرير على أي جزء من الكرت ليتحول للذهبي */
    .car__item:hover .car__item__text h5 a {
        color: #c18f54 !important;
        transition: color 0.3s ease;
    }

    /* حماية أزرار تحكم السلايدر (النقاط) لتبقى قابلة للضغط ولا يغطيها الرابط الشامل */
    .car__item .owl-dots, 
    .car__item .owl-nav {
        position: relative;
        z-index: 10;
    }

    /* فلترة الأقسام باللون الذهبي */
    .filter__controls li.active, .filter__controls li:hover {
        color: #c18f54 !important;
    }
    
    .filter__controls li.active::after {
        background: #c18f54 !important;
    }

    /* تأثير تمرير الماوس على رابط الاكتشاف */
    .discover-link:hover {
        color: #c18f54 !important;
    }
    
    .discover-link:hover i {
        transform: translateX(5px);
        color: #c18f54 !important;
    }
    
    .discover-link i {
        transition: transform 0.3s ease;
    }

    /* الألوان الخاصة بالأوسمة والأسعار */
    .car__item__price .car-option {
        background: #c2c2c2 !important;
        color: #111111 !important;
    }
    
    .car__item__price .car-option.sale {
        background: #c18f54 !important;
        color: #ffffff !important;
    }

    /* أنيميشن الهيكل العظمي الانتظاري */
    @keyframes pulse {
        0%, 100% { opacity: 1; }
        50% { opacity: .4; }
    }
</style>