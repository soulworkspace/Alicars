<section class="feature spad">
    <div class="container">
        <div class="row gy-5 align-items-center">
            
            <div class="col-lg-4 col-md-12 col-12">
                <div class="feature__text">
                    <div class="section-title">
                        <span>Nos Atouts</span>
                        <h2>Un nom de confiance dans l'automobile</h2>
                    </div>
                    <div class="feature__text__desc">
                        <p>Chez MB Motors, nous nous engageons à offrir une transparence totale pour chaque transaction d'achat, de vente ou d'échange de véhicule.</p>
                        <p>Chaque voiture de notre catalogue passe par une inspection rigoureuse de ses composants clés pour garantir votre sécurité et votre tranquillité d'esprit sur la route.</p>
                    </div>
                    <div class="feature__text__btn">
                        <a href="#" class="primary-btn">A propos de nous</a>
                        <a href="#" class="primary-btn partner-btn">Nos Partenaires</a>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4 offset-lg-4 col-md-12 col-12">
                <div class="row g-3">
                    
                    <div class="col-lg-6 col-md-4 col-6">
                        <div class="feature__item">
                            <div class="feature__item__icon">
                                <img src="{{ asset('front/img/feature/feature-1.png') }}" alt="Moteur" class="img-fluid">
                            </div>
                            <h6>Moteur</h6>
                        </div>
                    </div>
                    
                    <div class="col-lg-6 col-md-4 col-6">
                        <div class="feature__item">
                            <div class="feature__item__icon">
                                <img src="{{ asset('front/img/feature/feature-2.png') }}" alt="Turbo" class="img-fluid">
                            </div>
                            <h6>Turbo</h6>
                        </div>
                    </div>
                    
                    <div class="col-lg-6 col-md-4 col-6">
                        <div class="feature__item">
                            <div class="feature__item__icon">
                                <img src="{{ asset('front/img/feature/feature-3.png') }}" alt="Refroidissement" class="img-fluid">
                            </div>
                            <h6>Refroidissement</h6>
                        </div>
                    </div>
                    
                    <div class="col-lg-6 col-md-4 col-6">
                        <div class="feature__item">
                            <div class="feature__item__icon">
                                <img src="{{ asset('front/img/feature/feature-4.png') }}" alt="Suspension" class="img-fluid">
                            </div>
                            <h6>Suspension</h6>
                        </div>
                    </div>
                    
                    <div class="col-lg-6 col-md-4 col-6">
                        <div class="feature__item">
                            <div class="feature__item__icon">
                                <img src="{{ asset('front/img/feature/feature-5.png') }}" alt="Electricité" class="img-fluid">
                            </div>
                            <h6>Électricité</h6>
                        </div>
                    </div>
                    
                    <div class="col-lg-6 col-md-4 col-6">
                        <div class="feature__item">
                            <div class="feature__item__icon">
                                <img src="{{ asset('front/img/feature/feature-6.png') }}" alt="Freins" class="img-fluid">
                            </div>
                            <h6>Freins</h6>
                        </div>
                    </div>
                    
                </div>
            </div>
            
        </div>
    </div>
</section>

<!-- كود الـ CSS المدمج لحقن ألوان الهوية الجديدة دون المساس بالقوالب الأصلية -->
<style>
    /* تلوين العنوان الصغير بالذهبي الفخم */
    .feature .section-title span {
        color: #c18f54 !important;
    }

    /* زر "A propos de nous" الرئيسي بالخلفية الذهبية */
    .feature__text__btn .primary-btn:not(.partner-btn) {
        background: #c18f54 !important;
        border-color: #c18f54 !important;
        color: #fff !important;
    }

    /* زر "Nos Partenaires" الشفاف بالحدود الفضية */
    .feature__text__btn .partner-btn {
        background: transparent !important;
        border: 2px solid #c2c2c2 !important;
        color: #111111 !important;
    }

    /* تأثير الـ Hover على زر الشركاء ليتحول إلى الذهبي */
    .feature__text__btn .partner-btn:hover {
        border-color: #c18f54 !important;
        color: #c18f54 !important;
    }

    /* تأثير التمرير على مربعات المزايا (المحرك، الفرامل... إلخ) ليصبح تفاعلها ذهبياً */
    .feature__item:hover {
        border-color: #c18f54 !important;
        background: #fbf9f6 !important; /* خلفية خفيفة مريحة للعين ومتناسقة مع الذهبي */
    }
    
    .feature__item:hover h6 {
        color: #c18f54 !important;
    }
</style>