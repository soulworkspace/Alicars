<section class="chooseus spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-5 col-md-12">
                <div class="chooseus__text">
                    <div class="section-title">
                        <h2>Pourquoi Nous Choisir</h2>
                        <p>Nous nous engageons à vous fournir une expérience transparente et haut de gamme pour l'achat, la vente ou l'échange de votre véhicule.</p>
                    </div>
                    <ul>
                        <li><i class="fa fa-check-circle"></i> Un large catalogue de véhicules rigoureusement inspectés.</li>
                        <li><i class="fa fa-check-circle"></i> Des estimations d'échange justes et basées sur le marché.</li>
                        <li><i class="fa fa-check-circle"></i> Un accompagnement complet dans toutes vos démarches administratives.</li>
                        <li><i class="fa fa-check-circle"></i> Un service client réactif et à votre entière écoute.</li>
                    </ul>
                    <a href="#" class="primary-btn chooseus-btn">À Propos de Nous</a>
                </div>
            </div>
        </div>
    </div>
    <div class="chooseus__video set-bg" data-setbg="{{ asset('front/img/chooseus-video.png') }}">
        <img src="{{ asset('front/img/chooseus-video.png') }}" alt="Pourquoi nous choisir">
        <a href="https://www.youtube.com/watch?v=Xd0Ok-MkqoE" class="play-btn video-popup">
            <i class="fa fa-play"></i>
        </a>
    </div>
</section>

<!-- كود الـ CSS المدمج لحقن ألوان الهوية الجديدة دون المساس بالقوالب الأصلية -->
<style>
    /* تلوين أيقونات التحقق (Check Icons) بالذهبي الفخم */
    .chooseus__text ul li i {
        color: #c18f54 !important;
    }

    /* زر "À Propos de Nous" بالخلفية الذهبية */
    .chooseus__text .chooseus-btn {
        background: #c18f54 !important;
        border-color: #c18f54 !important;
        color: #ffffff !important;
    }

    /* زر تشغيل الفيديو التفاعلي (Play Button) باللون الذهبي */
    .chooseus__video .play-btn {
        background: #c18f54 !important;
        color: #ffffff !important;
    }

    /* تأثير النبض أو التموج حول زر التشغيل ليتناغم مع الهوية الجديدة */
    .chooseus__video .play-btn::after, 
    .chooseus__video .play-btn::before {
        background: #c18f54 !important;
    }
</style>